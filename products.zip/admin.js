(function() {
'use strict';
const adminState = {
  loggedIn: false,
  user: null,
  staff: [],
  products: [],
  sellers: [],
  coupons: [],
  announcements: [],
  productPage: 1,
  productPageSize: 25,
  editingProductId: null,
  editingCouponId: null,
  editingAnnouncementId: null,
  editingSellerId: null,
};
window.adminState = adminState;
const $ = (id) => document.getElementById(id);
function toast(msg) { const el = $('toast'); if (!el) return alert(msg); el.textContent = msg; el.style.opacity = '1'; el.style.transform = 'translateX(-50%) translateY(0)'; clearTimeout(el._t); el._t = setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(-50%) translateY(8px)'; }, 2400); }
function escapeHtml(str = '') { return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }
async function hashPassword(password) { const enc = new TextEncoder().encode(password); const buf = await crypto.subtle.digest('SHA-256', enc); return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join(''); }
function inferCategory(name = '') {
  const n = name.toLowerCase();
  if (/(shoe|sneaker|air force|jordan|yeezy|dunk|samba|gazelle|loafer|boot|trainer)/.test(n)) return 'shoes';
  if (/(jacket|coat|puffer|down|parka|windbreaker|anorak|fleece)/.test(n)) return 'outerwear';
  if (/(hoodie|tee|t-shirt|shirt|sweater|crewneck|jersey|polo|top)/.test(n)) return 'tops';
  if (/(jean|pant|trouser|cargo|short|bottom)/.test(n)) return 'bottoms';
  if (/(bag|belt|wallet|cap|hat|beanie|watch|glove|sock|scarf|glass|sunglass|ring|necklace)/.test(n)) return 'accessories';
  return 'other';
}
/* ── API helpers ── */
const API_TOKEN = 'rt-taro-admin-2025';
async function apiPost(resource, data) {
  try {
    const res = await fetch('/api/' + resource, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-Admin-Token': API_TOKEN },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return true;
  } catch (e) {
    console.error('API save failed for', resource, e);
    toast('⚠️ Save failed — check console');
    return false;
  }
}
async function apiGet(resource) {
  try {
    const res = await fetch('/api/' + resource, { cache: 'no-store' });
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    console.warn('API fetch failed for', resource, e);
    return null;
  }
}
/* Staff still uses localStorage (login credentials, not public content) */
function saveStaff() { localStorage.setItem('rt_staff', JSON.stringify(adminState.staff)); }
async function saveCoupons() { return await apiPost('coupons', adminState.coupons); }
async function saveProducts() { return await apiPost('products', adminState.products); }
async function saveSellers() { return await apiPost('sellers', adminState.sellers); }
async function saveAnnouncements() { return await apiPost('announcements', adminState.announcements); }
function seedDefaultCredentials() {
  return [
    { id:'staff_swifty',  username:'swifty',  password:'Kacperek##2010', role:'dev',   hashed:false, created_at:new Date().toISOString() },
    { id:'staff_tony1',   username:'tony1',   password:'Pfannkuchen10',  role:'owner', hashed:false, created_at:new Date().toISOString() },
  ];
}
// Old usernames that must be purged if found in localStorage
const LEGACY_USERNAMES = ['dev-swifty','owner-tony1'];
async function loadOrBootstrapStaff() {
  const defaults = seedDefaultCredentials();
  let savedStaff = localStorage.getItem('rt_staff');
  let parsed = [];
  try { parsed = JSON.parse(savedStaff || '[]'); } catch { parsed = []; }
  if (!Array.isArray(parsed)) parsed = [];

  // Remove any legacy usernames from old codebase
  parsed = parsed.filter(s => !LEGACY_USERNAMES.includes(String(s.username || '').toLowerCase()));

  // Ensure each default account exists (never remove user-created accounts)
  for (const def of defaults) {
    const exists = parsed.find(s => String(s.username||'').toLowerCase() === def.username.toLowerCase());
    if (!exists) parsed.push({ ...def });
  }

  adminState.staff = parsed;
  let changed = false;
  for (const s of adminState.staff) {
    s.username = String(s.username || '').trim().toLowerCase();
    if (!s.hashed && s.password) {
      s.password = await hashPassword(s.password);
      s.hashed = true;
      changed = true;
    }
  }
  saveStaff(); // always persist so legacy entries are purged
}
function normalizeAdminProduct(p, i) {
  const raw = String(p.category || p.tag || '').trim().toLowerCase();
  let priceVal = parseFloat(p.price || p.sellPrice || 0) || 0;
  // Convert legacy CNY to USD if value looks like CNY (e.g., > 200)
  if (priceVal > 200) {
    priceVal = priceVal * (window.RATES?.USD || 0.138);
  }
  return {
    id: p.id || ('p' + i),
    name: String(p.name || '').trim(),
    category: (!raw || raw === 'other') ? inferCategory(p.name || '') : raw,
    seller: String(p.seller || p.agentName || 'Unknown').trim(),
    price: priceVal,
    featured: Boolean(p.featured),
    image: p.image || p.imageUrl || p.photo || '',
    link: p.link || p.litbuy || p.litbuy_link || p.agentUrl || '#',
    qc_available: Boolean(p.qc_available || p.qc),
    qc_images: Array.isArray(p.qc_images) ? p.qc_images : (Array.isArray(p.qcImages) ? p.qcImages : []),
    dateAdded: p.dateAdded || new Date().toISOString().slice(0, 10),
    // Preserve extended fields for editing
    bestBatch: p.bestBatch || p.best_batch || '',
    bestPrice: p.bestPrice || p.best_price || '',
    bestBatchLinks: p.bestBatchLinks || p.best_batch_links || [],
    budgetBatch: p.budgetBatch || p.budget_batch || '',
    budgetPrice: p.budgetPrice || p.budget_price || '',
    budgetBatchLinks: p.budgetBatchLinks || p.budget_batch_links || [],
    picsLinks: p.picsLinks || p.qc_images || [],
    notes: p.notes || ''
  };
}
function normalizeAdminSeller(s, idx) {
  const raw = s && typeof s === 'object' ? s : {};
  const id = raw.id != null && String(raw.id).trim() !== '' ? String(raw.id).trim() : ('s_' + idx + '_' + Date.now());
  return {
    id,
    name: String(raw.name || '').trim(),
    description: String(raw.description || '').replace(/\r\n/g, ' ').replace(/\r/g, ' '),
    logo: String(raw.logo || '').trim(),
    link: String(raw.link || '#').replace(/\\\//g, '/'),
    verified: raw.verified !== false,
    pinned: Boolean(raw.pinned),
    dateAdded: raw.dateAdded || new Date().toISOString().slice(0, 19).replace('T', ' '),
  };
}
async function loadAdminData() {
  /* 1. Try API (server-side KV — visible to all users) */
  const [apiProducts, apiSellers, hiddenProducts] = await Promise.all([apiGet('products'), apiGet('sellers'), apiGet('hidden-products')]);

  /* Load hidden products list */
  adminState.hiddenProducts = Array.isArray(hiddenProducts) ? hiddenProducts : [];

  /* Products: API → fallback to products.json → fallback to products/index.json */
  if (Array.isArray(apiProducts) && apiProducts.length) {
    adminState.products = apiProducts.map(normalizeAdminProduct);
  } else {
    try {
      const pr = await fetch('products.json', { cache: 'no-store' }).then(r => r.json());
      adminState.products = Array.isArray(pr) ? pr.map(normalizeAdminProduct) : [];
    } catch {
      adminState.products = [];
    }
  }

  /* Also load folder products from products/index.json */
  try {
    const folderRes = await fetch('products/index.json', { cache: 'no-store' });
    const folderData = await folderRes.json();
    if (Array.isArray(folderData)) {
      // Create set of hidden product IDs to filter out
      const hiddenIds = new Set((adminState.hiddenProducts || []).map(String));
      const folderProducts = folderData.map((p, i) => {
        const bestPriceMatch = String(p.best_price || '').match(/[\d.]+/);
        const budgetPriceMatch = String(p.budget_price || '').match(/[\d.]+/);
        const bestPriceUsd = bestPriceMatch ? parseFloat(bestPriceMatch[0]) || 0 : 0;
        const budgetPriceUsd = budgetPriceMatch ? parseFloat(budgetPriceMatch[0]) || 0 : 0;
        const chosenUsd = bestPriceUsd || budgetPriceUsd || 0;
        return {
          id: p.id || p.folder || ('folder_' + i),
          name: (p.name || '').trim().replace(/\n/g, ' '),
          category: (p.subcategory || p.category || '').toLowerCase().trim() || inferCategory(p.name || ''),
          seller: p.best_batch || p.budget_batch || 'Multiple batches',
          price: chosenUsd,
          featured: p.featured === true || i < 12,
          image: p.local_image ? `products/${p.folder}/${p.local_image}` : (p.image_url || ''),
          link: (Array.isArray(p.best_batch_links) && p.best_batch_links[0]?.url) ||
                (Array.isArray(p.budget_batch_links) && p.budget_batch_links[0]?.url) ||
                '#',
          qc_available: false,
          qc_images: [],
          dateAdded: new Date().toISOString().slice(0, 10),
          _folderProduct: true,
          folder: p.folder || '',
          // Preserve extended fields for editing
          bestBatch: p.best_batch || '',
          bestPrice: p.best_price || '',
          bestBatchLinks: p.best_batch_links || [],
          budgetBatch: p.budget_batch || '',
          budgetPrice: p.budget_price || '',
          budgetBatchLinks: p.budget_batch_links || [],
          picsLinks: p.pics_links || p.qc_links || [],
          notes: p.notes || ''
        };
      });
      // Merge: admin products first, deduplicate by id, filter hidden
      const existingIds = new Set(adminState.products.map(p => String(p.id)));
      const newFolderProducts = folderProducts.filter(p => !existingIds.has(String(p.id)) && !hiddenIds.has(String(p.id)));
      adminState.products = [...adminState.products, ...newFolderProducts];
    }
  } catch (e) {
    console.warn('Failed to load folder products:', e);
  }

  /* Sellers: API → fallback to sellers.json */
  if (Array.isArray(apiSellers) && apiSellers.length) {
    adminState.sellers = apiSellers;
  } else {
    try {
      const sr = await fetch('sellers.json', { cache: 'no-store' }).then(r => r.json());
      adminState.sellers = Array.isArray(sr) ? sr : [];
    } catch { adminState.sellers = []; }
  }
  adminState.sellers = adminState.sellers.map((s, i) => normalizeAdminSeller(s, i));
}
async function loadCoupons() {
  const api = await apiGet('coupons');
  if (Array.isArray(api)) { adminState.coupons = api; return; }
  /* fallback: old localStorage */
  try { adminState.coupons = JSON.parse(localStorage.getItem('rt_coupons') || '[]'); } catch { adminState.coupons = []; }
}
async function loadAnnouncements() {
  const api = await apiGet('announcements');
  if (Array.isArray(api)) { adminState.announcements = api; return; }
  /* fallback: old localStorage */
  try { adminState.announcements = JSON.parse(localStorage.getItem('rt_announcements') || '[]'); } catch { adminState.announcements = []; }
}
async function adminLogin(event) {
  if (event) event.preventDefault();
  const username = ($('loginUsername')?.value || '').trim().toLowerCase();
  const password = $('loginPassword')?.value || '';
  const errorEl = $('loginError');
  if (errorEl) {
    errorEl.style.display = 'none';
    errorEl.textContent = '';
  }
  if (!username || !password) {
    errorEl.textContent = 'Please enter username and password';
    errorEl.style.display = 'block';
    return false;
  }
  const hashed = await hashPassword(password);
  const staff = adminState.staff.find(s => s.username === username && s.password === hashed);
  if (!staff) {
    errorEl.textContent = 'Invalid username or password';
    errorEl.style.display = 'block';
    $('loginPassword').value = '';
    return false;
  }
  adminState.user = staff;
  adminState.loggedIn = true;
  localStorage.setItem('rt_admin_session', JSON.stringify({ username: staff.username, role: staff.role }));
  syncNav();
  showDashboard();
  toast(`Welcome back, ${staff.username}`);
  return false;
}
function adminLogout() {
  localStorage.removeItem('rt_admin_session');
  adminState.loggedIn = false;
  adminState.user = null;
  showLogin();
  toast('Logged out');
}
function syncNav() {
  if ($('adminNavActions')) $('adminNavActions').style.display = adminState.loggedIn ? 'flex' : 'none';
  if ($('adminNavLogin')) $('adminNavLogin').style.display = adminState.loggedIn ? 'none' : 'flex';
  if ($('navUserName')) $('navUserName').textContent = adminState.user?.username || 'Guest';
  if ($('navUserRole')) $('navUserRole').textContent = adminState.user?.role || '—';
}
function showLogin() {
  if ($('adminLogin')) $('adminLogin').style.display = 'grid';
  if ($('adminDashboard')) $('adminDashboard').style.display = 'none';
  syncNav();
}
function roleCanManageStaff() {
  return ['owner','dev'].includes(adminState.user?.role);
}
function showDashboard() {
  if ($('adminLogin')) $('adminLogin').style.display = 'none';
  if ($('adminDashboard')) $('adminDashboard').style.display = 'block';
  const badge = $('adminRoleBadge');
  if (badge) {
    const role = adminState.user?.role || 'staff';
    badge.textContent = role.toUpperCase();
    badge.className = 'role-badge role-' + role;
  }
  updateKPIs();
  renderAdminProductList();
  renderSellerList();
  renderStaffList();
  renderCouponList();
  renderAnnouncementList();
  loadSettingToggles();
  syncNav();
}
function updateKPIs() {
  if ($('adminProducts')) $('adminProducts').textContent = adminState.products.length.toLocaleString();
  if ($('adminSellers')) $('adminSellers').textContent = adminState.sellers.length.toLocaleString();
  if ($('adminStaff')) $('adminStaff').textContent = adminState.staff.length.toLocaleString();
  if ($('adminCoupons')) $('adminCoupons').textContent = adminState.coupons.length.toLocaleString();
}
function linksToString(arr) {
  if (!Array.isArray(arr) || !arr.length) return '';
  try { return JSON.stringify(arr); } catch { return ''; }
}
function parseLinks(val) {
  val = (val || '').trim();
  if (!val) return [];
  try {
    const parsed = JSON.parse(val);
    if (Array.isArray(parsed)) return parsed;
  } catch {}
  // fallback: comma-separated URLs
  return val.split(',').map(u => u.trim()).filter(Boolean).map((u, i) => ({ label: 'Link ' + (i+1), url: u }));
}
function fillProductForm(p = null) {
  adminState.editingProductId = p?.id || null;
  $('productFormTitle').textContent = p ? 'Edit product' : 'Add product';
  $('productSubmitBtn').textContent = p ? 'Save product' : 'Add product';
  $('addProdName').value = p?.name || '';
  $('addProdCategory').value = p?.category || '';
  $('addProdImage').value = p?.image || p?.imageUrl || '';
  $('addProdSeller').value = p?.seller || '';
  $('addProdBestBatch').value = p?.bestBatch || p?.best_batch || '';
  $('addProdBestPrice').value = p?.bestPrice || p?.best_price || '';
  $('addProdBestLinks').value = linksToString(p?.bestBatchLinks || p?.best_batch_links || []);
  $('addProdBudgetBatch').value = p?.budgetBatch || p?.budget_batch || '';
  $('addProdBudgetPrice').value = p?.budgetPrice || p?.budget_price || '';
  $('addProdBudgetLinks').value = linksToString(p?.budgetBatchLinks || p?.budget_batch_links || []);
  $('addProdQC').value = linksToString(p?.picsLinks || p?.qc_images || []);
  $('addProdNotes').value = p?.notes || '';
  $('addProdFeatured').checked = Boolean(p?.featured);
}
function clearProductForm() { fillProductForm(null); }
async function upsertProduct() {
  const name = $('addProdName')?.value.trim();
  if (!name) return toast('Add a product name');
  const category = ($('addProdCategory')?.value || '').trim().toLowerCase() || inferCategory(name);
  const image = $('addProdImage')?.value.trim() || '';
  const seller = $('addProdSeller')?.value.trim() || '';
  const bestBatch = $('addProdBestBatch')?.value.trim() || '';
  const bestPrice = $('addProdBestPrice')?.value.trim() || '';
  const bestBatchLinks = parseLinks($('addProdBestLinks')?.value || '');
  const budgetBatch = $('addProdBudgetBatch')?.value.trim() || '';
  const budgetPrice = $('addProdBudgetPrice')?.value.trim() || '';
  const budgetBatchLinks = parseLinks($('addProdBudgetLinks')?.value || '');
  const picsLinks = parseLinks($('addProdQC')?.value || '');
  const notes = $('addProdNotes')?.value.trim() || '';
  const featured = Boolean($('addProdFeatured')?.checked);
  const primaryLink = (bestBatchLinks[0]?.url || budgetBatchLinks[0]?.url || '#');
  const priceMatch = String(bestPrice || budgetPrice || '').match(/[\d.]+/);
  const priceUsd = priceMatch ? parseFloat(priceMatch[0]) : 0;
  const record = {
    id: adminState.editingProductId || ('p' + Date.now()),
    name, category, image, seller,
    price: priceUsd,
    bestBatch, bestPrice, bestBatchLinks,
    budgetBatch, budgetPrice, budgetBatchLinks,
    picsLinks, notes, featured,
    link: primaryLink,
    dateAdded: new Date().toISOString().slice(0, 10)
  };
  if (adminState.editingProductId) {
    adminState.products = adminState.products.map(p => p.id === record.id ? record : p);
    toast('Product updated');
  } else {
    adminState.products.unshift(record);
    toast('Product added');
  }
  const saved = await saveProducts();
  if (!saved) {
    toast('⚠️ Failed to save product');
    return;
  }
  updateKPIs(); renderAdminProductList(); clearProductForm();
}
function editProduct(id) { const product = adminState.products.find(p => String(p.id) === String(id)); if (!product) return; fillProductForm(product); window.scrollTo({ top:0, behavior:'smooth' }); }
async function deleteProduct(id) {
  const product = adminState.products.find(p => String(p.id) === String(id));
  if (!product) return;
  if (!confirm(`Delete ${product.name}?`)) return;
  adminState.products = adminState.products.filter(p => String(p.id) !== String(id));
  const saved = await saveProducts();
  if (!saved) {
    toast('⚠️ Failed to save deletion — product may reappear');
    return;
  }
  // If it's a folder product, add to hidden-products list
  if (product._folderProduct) {
    await apiPost('hidden-products', (adminState.hiddenProducts || []).concat(String(id)));
  }
  updateKPIs();
  renderAdminProductList();
  toast('Product deleted');
}
function renderAdminProductList() {
  const list = $('adminProductList');
  if (!list) return;
  const q = ($('prodSearch')?.value || '').toLowerCase();
  const filtered = adminState.products.filter(p => !q || `${p.name} ${p.seller} ${p.category}`.toLowerCase().includes(q));
  const totalPages = Math.max(1, Math.ceil(filtered.length / adminState.productPageSize));
  adminState.productPage = Math.min(adminState.productPage, totalPages);
  const start = (adminState.productPage - 1) * adminState.productPageSize;
  const items = filtered.slice(start, start + adminState.productPageSize);
  const fmtPrice = (p) => {
    if (typeof window.fmt === 'function') return window.fmt(p.price || 0);
    return '$' + Number(p.price || 0).toFixed(2);
  };
  list.innerHTML = !items.length ? `<div style="padding:18px;color:var(--muted)">No products found.</div>` : items.map(p => `<div class="admin-row"><div class="admin-row-thumb">${p.image ? `<img src="${escapeHtml(p.image)}" style="width:100%;height:100%;object-fit:cover;">` : '📦'}</div><div style="flex:1;min-width:0;"><div style="font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(p.name)}</div><div style="font-size:12px;color:var(--muted);">${escapeHtml(p.category)} · ${escapeHtml(p.seller)} · ${escapeHtml(p.dateAdded || '')}</div></div><div style="font-weight:800;color:var(--blue);">${fmtPrice(p)}</div><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;"><button class="btn btn-ghost btn-sm" type="button" onclick="editProduct('${escapeHtml(p.id)}')">Edit</button><button class="btn btn-danger btn-sm" type="button" onclick="deleteProduct('${escapeHtml(p.id)}')">Delete</button></div></div>`).join('');
  const pager = $('productPager');
  if (pager) pager.innerHTML = `<button class="btn btn-ghost btn-sm" type="button" ${adminState.productPage <= 1 ? 'disabled' : ''} onclick="changeProductPage(-1)">← Prev</button><span class="pager-label">Page ${adminState.productPage} of ${totalPages} · ${filtered.length.toLocaleString()} products</span><button class="btn btn-ghost btn-sm" type="button" ${adminState.productPage >= totalPages ? 'disabled' : ''} onclick="changeProductPage(1)">Next →</button>`;
}
function changeProductPage(delta) { adminState.productPage = Math.max(1, adminState.productPage + delta); renderAdminProductList(); }
function fillSellerForm(s = null) {
  adminState.editingSellerId = s?.id || null;
  const title = $('sellerFormTitle'); const btn = $('sellerSubmitBtn');
  if (title) title.textContent = s ? 'Edit seller' : 'Add seller';
  if (btn) btn.textContent = s ? 'Save seller' : 'Add seller';
  if ($('addSellerName')) $('addSellerName').value = s?.name || '';
  if ($('addSellerDesc')) $('addSellerDesc').value = s?.description || '';
  if ($('addSellerLogo')) $('addSellerLogo').value = s?.logo || '';
  if ($('addSellerLink')) $('addSellerLink').value = !s ? '' : ((s.link && String(s.link).trim() && s.link !== '#') ? s.link : '');
  if ($('addSellerVerified')) $('addSellerVerified').checked = s ? s.verified !== false : true;
  if ($('addSellerPriority')) $('addSellerPriority').checked = Boolean(s?.pinned);
}
function clearSellerForm() { fillSellerForm(null); }
function upsertSeller() {
  const name = ($('addSellerName')?.value || '').trim();
  if (!name) return toast('Add a seller name');
  const description = ($('addSellerDesc')?.value || '').trim();
  const logo = ($('addSellerLogo')?.value || '').trim();
  const link = ($('addSellerLink')?.value || '').trim() || '#';
  const verified = Boolean($('addSellerVerified')?.checked);
  const pinned = Boolean($('addSellerPriority')?.checked);
  const prev = adminState.editingSellerId ? adminState.sellers.find(x => x.id === adminState.editingSellerId) : null;
  const record = {
    id: adminState.editingSellerId || ('s' + Date.now()),
    name,
    description,
    logo,
    link: link.replace(/\\\//g, '/'),
    verified,
    pinned,
    dateAdded: prev?.dateAdded || new Date().toISOString().slice(0, 19).replace('T', ' '),
  };
  if (adminState.editingSellerId) {
    adminState.sellers = adminState.sellers.map(x => x.id === record.id ? record : x);
    toast('Seller updated');
  } else {
    adminState.sellers.unshift(record);
    toast('Seller added');
  }
  await saveSellers();
  clearSellerForm();
  updateKPIs();
  renderSellerList();
}
function editSeller(id) {
  const s = adminState.sellers.find(x => String(x.id) === String(id));
  if (!s) return;
  fillSellerForm(s);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
async function deleteSeller(id) {
  const s = adminState.sellers.find(x => String(x.id) === String(id));
  if (!s) return;
  if (!confirm(`Remove ${s.name} from the directory?`)) return;
  adminState.sellers = adminState.sellers.filter(x => String(x.id) !== String(id));
  if (adminState.editingSellerId === id) clearSellerForm();
  await saveSellers();
  updateKPIs();
  renderSellerList();
  toast('Seller removed');
}
async function moveSeller(index, delta) {
  const j = index + delta;
  if (j < 0 || j >= adminState.sellers.length) return;
  const arr = adminState.sellers;
  [arr[index], arr[j]] = [arr[j], arr[index]];
  await saveSellers();
  renderSellerList();
}
async function toggleSellerPinned(index) {
  const s = adminState.sellers[index];
  if (!s) return;
  s.pinned = !s.pinned;
  await saveSellers();
  renderSellerList();
  toast(s.pinned ? 'Listed first on the site' : 'Normal order');
}
function renderSellerList() {
  const list = $('adminSellerList');
  if (!list) return;
  if (!adminState.sellers.length) {
    list.innerHTML = '<div style="color:var(--muted)">No sellers yet.</div>';
    return;
  }
  list.innerHTML = adminState.sellers.map((s, i) => {
    const priorityBadge = s.pinned ? '<span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:999px;background:rgba(100,149,237,.15);color:var(--blue)">First in list</span>' : '';
    return `<div class="admin-mini-card" style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px;">
      <div style="flex:1;min-width:160px">
        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><span style="font-weight:700">${escapeHtml(s.name || 'Unknown')}</span>${priorityBadge}</div>
        <div style="font-size:12px;color:var(--muted);">${escapeHtml(s.description || 'No description')}</div>
      </div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end;">
        <button class="btn btn-ghost btn-sm" type="button" ${i <= 0 ? 'disabled' : ''} onclick="moveSeller(${i},-1)">↑</button>
        <button class="btn btn-ghost btn-sm" type="button" ${i >= adminState.sellers.length - 1 ? 'disabled' : ''} onclick="moveSeller(${i},1)">↓</button>
        <button class="btn btn-ghost btn-sm" type="button" onclick="toggleSellerPinned(${i})">${s.pinned ? 'Normal order' : 'List first'}</button>
        <button class="btn btn-ghost btn-sm" type="button" onclick="editSeller('${escapeHtml(String(s.id))}')">Edit</button>
        <button class="btn btn-danger btn-sm" type="button" onclick="deleteSeller('${escapeHtml(String(s.id))}')">Delete</button>
      </div>
    </div>`;
  }).join('');
}
function renderStaffList() {
  const list = $('staffList');
  if (!list) return;
  list.innerHTML = adminState.staff.map(s => `<div class="admin-mini-card" style="display:flex;justify-content:space-between;gap:12px;align-items:center;"><div><div style="font-weight:700;">${escapeHtml(s.username)}</div><div style="font-size:12px;color:var(--muted);">${escapeHtml(s.role)}</div></div>${roleCanManageStaff() ? `<button class="btn btn-danger btn-sm" type="button" onclick="removeStaff('${escapeHtml(s.id)}')">Remove</button>` : ''}</div>`).join('');
}
function removeStaff(id) {
  if (!roleCanManageStaff()) return;
  const s = adminState.staff.find(x => x.id === id);
  // Protect default accounts
  if (s && ['swifty','tony1'].includes(s.username)) return toast('Cannot remove owner/dev accounts');
  adminState.staff = adminState.staff.filter(s => s.id !== id);
  saveStaff(); updateKPIs(); renderStaffList(); toast('Staff removed');
}
async function createStaff() {
  if (!roleCanManageStaff()) return toast('No permission');
  const username = ($('newStaffUsername')?.value || '').trim().toLowerCase();
  const password = $('newStaffPassword')?.value || '';
  const role = $('newStaffRole')?.value || 'staff';
  const errEl = $('staffCreateError');
  if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
  if (!username || !password) {
    if (errEl) { errEl.textContent = 'Enter username and password'; errEl.style.display = 'block'; }
    return;
  }
  if (password.length < 6) {
    if (errEl) { errEl.textContent = 'Password must be at least 6 characters'; errEl.style.display = 'block'; }
    return;
  }
  if (adminState.staff.find(s => s.username === username)) {
    if (errEl) { errEl.textContent = 'Username already exists'; errEl.style.display = 'block'; }
    return;
  }
  const hashed = await hashPassword(password);
  const newStaff = { id: 'staff_' + Date.now(), username, password: hashed, hashed: true, role, created_at: new Date().toISOString() };
  adminState.staff.push(newStaff);
  saveStaff(); updateKPIs(); renderStaffList();
  $('newStaffUsername').value = ''; $('newStaffPassword').value = '';
  toast(`Account created: ${username} (${role})`);
}
function fillCouponForm(c = null) {
  adminState.editingCouponId = c?.id || null;
  $('couponFormTitle').textContent = c ? 'Edit coupon' : 'Add coupon';
  $('couponSubmitBtn').textContent = c ? 'Save coupon' : 'Add coupon';
  $('newCouponTitle').value = c?.title || '';
  $('newCouponCode').value = c?.code || '';
  $('newCouponMessage').value = c?.message || '';
  $('newCouponUrl').value = c?.url || '';
  $('newCouponButton').value = c?.button || 'Register Now';
  $('newCouponPhotoLink').value = c?.photoLink || '';
  $('newCouponButtonLink').value = c?.buttonLink || c?.url || '';
  $('newCouponButtonName').value = c?.buttonName || c?.button || 'Register Now';
  $('newCouponName').value = c?.couponName || c?.title || '';
  $('newCouponAgentName').value = c?.agentName || '';
}
function clearCouponForm() { fillCouponForm(null); }
async function addCoupon() {
  const record = {
    id: adminState.editingCouponId || ('c_' + Date.now()),
    enabled: true,
    title: $('newCouponTitle')?.value.trim(),
    code: ($('newCouponCode')?.value || '').trim().toUpperCase(),
    message: $('newCouponMessage')?.value.trim() || '',
    url: $('newCouponUrl')?.value.trim() || '#',
    button: $('newCouponButton')?.value.trim() || 'Register Now',
    photoLink: $('newCouponPhotoLink')?.value.trim() || '',
    buttonLink: $('newCouponButtonLink')?.value.trim() || '#',
    buttonName: $('newCouponButtonName')?.value.trim() || 'Register Now',
    couponName: $('newCouponName')?.value.trim() || '',
    agentName: $('newCouponAgentName')?.value.trim() || ''
  };
  if (!record.title || !record.code) return toast('Add a coupon title and code');
  if (adminState.editingCouponId) {
    adminState.coupons = adminState.coupons.map(c => c.id === record.id ? { ...c, ...record } : c);
    toast('Coupon updated');
  } else {
    adminState.coupons.unshift(record);
    toast('Coupon added');
  }
  await saveCoupons();
  clearCouponForm();
  renderCouponList();
  updateKPIs();
}
function editCoupon(id) { const coupon = adminState.coupons.find(c => c.id === id); if (!coupon) return; fillCouponForm(coupon); window.scrollTo({ top: document.body.scrollHeight * 0.35, behavior:'smooth' }); }
async function deleteCoupon(id) { adminState.coupons = adminState.coupons.filter(c => c.id !== id); await saveCoupons(); renderCouponList(); updateKPIs(); toast('Coupon deleted'); }
async function toggleCoupon(id) { adminState.coupons = adminState.coupons.map(c => c.id === id ? { ...c, enabled: !c.enabled } : c); await saveCoupons(); renderCouponList(); toast('Coupon updated'); }
function renderCouponList() {
  const list = $('couponList');
  if (!list) return;
  list.innerHTML = adminState.coupons.map(c => `<div class="admin-mini-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;"><div><div style="font-weight:700;">${escapeHtml(c.title)}</div><div style="font-size:12px;color:var(--muted);">${escapeHtml(c.code)} · ${escapeHtml(c.agentName || 'No agent')} · ${c.enabled ? 'Enabled' : 'Disabled'}</div></div><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;"><button class="btn btn-ghost btn-sm" type="button" onclick="editCoupon('${escapeHtml(c.id)}')">Edit</button><button class="btn btn-ghost btn-sm" type="button" onclick="toggleCoupon('${escapeHtml(c.id)}')">${c.enabled ? 'Disable' : 'Enable'}</button><button class="btn btn-danger btn-sm" type="button" onclick="deleteCoupon('${escapeHtml(c.id)}')">Delete</button></div></div>`).join('') || '<div style="color:var(--muted)">No coupons yet.</div>';
}
function fillAnnouncementForm(a = null) {
  adminState.editingAnnouncementId = a?.id || null;
  $('announcementFormTitle').textContent = a ? 'Edit announcement' : 'Add announcement';
  $('announcementSubmitBtn').textContent = a ? 'Save announcement' : 'Add announcement';
  $('newAnnouncementTitle').value = a?.title || '';
  $('newAnnouncementText').value = a?.text || '';
  $('newAnnouncementTag').value = a?.tag || 'update';
  $('newAnnouncementIcon').value = a?.icon || '📣';
  $('newAnnouncementButtonName').value = a?.buttonName || '';
  $('newAnnouncementButtonLink').value = a?.buttonLink || '';
}
function clearAnnouncementForm() { fillAnnouncementForm(null); }
async function addAnnouncement() {
  const now = new Date();
  const record = {
    id: adminState.editingAnnouncementId || ('a_' + Date.now()),
    enabled: true,
    title: $('newAnnouncementTitle')?.value.trim(),
    text: $('newAnnouncementText')?.value.trim(),
    tag: $('newAnnouncementTag')?.value.trim() || 'update',
    icon: $('newAnnouncementIcon')?.value.trim() || '📣',
    buttonName: $('newAnnouncementButtonName')?.value.trim() || '',
    buttonLink: $('newAnnouncementButtonLink')?.value.trim() || '',
    time: now.toLocaleDateString('en-GB', {day:'numeric',month:'short',year:'numeric'}),
    created_at: now.toISOString()
  };
  if (!record.title || !record.text) return toast('Add an announcement title and text');
  if (adminState.editingAnnouncementId) {
    adminState.announcements = adminState.announcements.map(a => a.id === record.id ? { ...a, ...record } : a);
    toast('Announcement updated');
  } else {
    adminState.announcements.unshift(record);
    toast('Announcement added');
  }
  await saveAnnouncements();
  clearAnnouncementForm();
  renderAnnouncementList();
}
function editAnnouncement(id) { const item = adminState.announcements.find(a => a.id === id); if (!item) return; fillAnnouncementForm(item); window.scrollTo({ top: document.body.scrollHeight * 0.6, behavior:'smooth' }); }
async function deleteAnnouncement(id) { adminState.announcements = adminState.announcements.filter(a => a.id !== id); await saveAnnouncements(); renderAnnouncementList(); toast('Announcement deleted'); }
async function toggleAnnouncement(id) { adminState.announcements = adminState.announcements.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a); await saveAnnouncements(); renderAnnouncementList(); toast('Announcement updated'); }
function renderAnnouncementList() {
  const list = $('announcementList');
  if (!list) return;
  list.innerHTML = adminState.announcements.map(a => `<div class="admin-mini-card" style="display:flex;align-items:center;justify-content:space-between;gap:12px;"><div><div style="font-weight:700;">${escapeHtml(a.icon || '📣')} ${escapeHtml(a.title)}</div><div style="font-size:12px;color:var(--muted);">${escapeHtml(a.tag || 'update')} · ${a.enabled ? 'Enabled' : 'Disabled'}${a.buttonLink ? ` · ${escapeHtml(a.buttonLink)}` : ''}</div></div><div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end;"><button class="btn btn-ghost btn-sm" type="button" onclick="editAnnouncement('${escapeHtml(a.id)}')">Edit</button><button class="btn btn-ghost btn-sm" type="button" onclick="toggleAnnouncement('${escapeHtml(a.id)}')">${a.enabled ? 'Disable' : 'Enable'}</button><button class="btn btn-danger btn-sm" type="button" onclick="deleteAnnouncement('${escapeHtml(a.id)}')">Delete</button></div></div>`).join('') || '<div style="color:var(--muted)">No announcements yet.</div>';
}
function toggleSetting(name) {
  const key = 'rt_setting_' + name;
  const next = !(localStorage.getItem(key) === '1');
  localStorage.setItem(key, next ? '1' : '0');
  loadSettingToggles();
  toast(name === 'maintenance' ? `Maintenance mode ${next ? 'enabled' : 'disabled'}${adminState.loggedIn ? ' — visitors are blocked, you still see staff preview' : ''}` : 'Setting updated');
}
function loadSettingToggles() {
  [['coupon','couponToggle',true],['maintenance','maintenanceToggle',false],['registration','registrationToggle',true],['beta','betaToggle',false]].forEach(([key,id,def]) => {
    const el = $(id);
    if (!el) return;
    const raw = localStorage.getItem('rt_setting_' + key);
    const on = raw === null ? def : raw === '1';
    el.classList.toggle('on', on);
  });
  const info = $('betaInfoText');
  if (info) info.textContent = 'Beta features currently include: staff quick actions on product cards, richer coupon popup fields, admin product pagination, and announcement quick links.';
}
function showBetaInfo() {
  alert('Beta features:\n\n• Staff edit/delete buttons directly on homepage and catalogue product cards\n• Expanded coupon popup fields: photo link, button link, button name, coupon name, agent name\n• Faster paged product management in admin\n• Announcement quick links with variables like page:guides or category:shoes');
}
function clearCache() {
  toast('No remote cache to clear on static hosting');
}
function resetData() {
  if (!confirm('Reset local admin, coupons, products, sellers and announcements on this browser?')) return;
  ['rt_staff','rt_admin_session','rt_coupons','rt_products_override','rt_sellers_override','rt_announcements'].forEach(k => localStorage.removeItem(k));
  toast('Local data reset. Reloading...');
  setTimeout(() => location.reload(), 700);
}
function bindAdminEvents() {
  const loginForm = $('loginForm');
  const loginBtn = $('loginBtn');
  const loginUsername = $('loginUsername');
  const loginPassword = $('loginPassword');
  loginForm?.addEventListener('submit', async (event) => { event.preventDefault(); event.stopPropagation(); await adminLogin(event); return false; });
  loginBtn?.addEventListener('click', async (event) => { event.preventDefault(); event.stopPropagation(); await adminLogin(event); });
  [loginUsername, loginPassword].forEach((field) => field?.addEventListener('keydown', async (event) => { if (event.key === 'Enter') { event.preventDefault(); event.stopPropagation(); await adminLogin(event); } }));
  $('logoutBtn')?.addEventListener('click', adminLogout);
  $('prodSearch')?.addEventListener('input', () => { adminState.productPage = 1; renderAdminProductList(); });
  $('productPageSize')?.addEventListener('change', () => { adminState.productPageSize = parseInt($('productPageSize').value,10) || 25; adminState.productPage = 1; renderAdminProductList(); });
}
async function initAdmin() {
  bindAdminEvents();
  await loadOrBootstrapStaff();
  await loadAdminData();
  await loadCoupons();
  await loadAnnouncements();
  fillProductForm(null);
  fillCouponForm(null);
  fillAnnouncementForm(null);
  fillSellerForm(null);
  const session = localStorage.getItem('rt_admin_session');
  if (session) {
    try {
      const data = JSON.parse(session);
      const staff = adminState.staff.find(s => s.username === String(data.username || '').toLowerCase());
      if (staff) {
        adminState.user = staff;
        adminState.loggedIn = true;
        showDashboard();
        return;
      }
    } catch {}
  }
  showLogin();
  updateKPIs();
}
document.addEventListener('DOMContentLoaded', initAdmin);
window.adminLogin = adminLogin; window.adminLogout = adminLogout; window.createStaff = createStaff; window.upsertProduct = upsertProduct; window.clearProductForm = clearProductForm; window.editProduct = editProduct; window.deleteProduct = deleteProduct; window.changeProductPage = changeProductPage; window.addCoupon = addCoupon; window.clearCouponForm = clearCouponForm; window.editCoupon = editCoupon; window.deleteCoupon = deleteCoupon; window.toggleCoupon = toggleCoupon; window.addAnnouncement = addAnnouncement; window.clearAnnouncementForm = clearAnnouncementForm; window.editAnnouncement = editAnnouncement; window.deleteAnnouncement = deleteAnnouncement; window.toggleAnnouncement = toggleAnnouncement; window.removeStaff = removeStaff; window.toggleSetting = toggleSetting; window.clearCache = clearCache; window.resetData = resetData; window.showBetaInfo = showBetaInfo;
window.upsertSeller = upsertSeller; window.clearSellerForm = clearSellerForm; window.editSeller = editSeller; window.deleteSeller = deleteSeller; window.moveSeller = moveSeller; window.toggleSellerPinned = toggleSellerPinned;
})();
